
# one-sample t-test
#http://www.stat.columbia.edu/~martin/W2024/R2.pdf
x = c(0.593, 0.142, 0.329, 0.691, 0.231, 0.793, 0.519, 0.392, 0.418)

t.test(x, alternative="greater", mu=0.3)